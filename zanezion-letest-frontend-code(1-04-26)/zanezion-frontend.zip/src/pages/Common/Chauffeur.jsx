import React, { useState } from 'react';
import { swalSuccess, swalError, swalWarning, swalInfo, swalConfirm, swalCredentials, swalCopied } from '../../utils/swal';
import {
    Car, Calendar, Clock, MapPin, Navigation,
    Plus, X, CheckCircle, Info, ArrowRight,
    Luggage, Clock4, Search, Filter, Edit2, Trash2
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useData } from '../../context/GlobalDataContext';
import Table from '../../components/Table';
import StatusBadge from '../../components/StatusBadge';

const Chauffeur = () => {
    const { 
        chauffeurRequests, 
        addChauffeurRequest, 
        updateChauffeurRequest, 
        deleteChauffeurRequest, 
        currentUser,
        users 
    } = useData();
    
    const [showModal, setShowModal] = useState(false);
    const [editingRequest, setEditingRequest] = useState(null);
    const [modalType, setModalType] = useState('create'); // create, edit, view
    const [serviceType, setServiceType] = useState('One Way');
    const [hasLuggage, setHasLuggage] = useState(false);
    const [hasStops, setHasStops] = useState(false);
    const [amenities, setAmenities] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    const isAdmin = ['superadmin', 'super_admin', 'concierge', 'operations'].includes(currentUser?.role?.toLowerCase());

    const filteredRequests = chauffeurRequests.filter(req => {
        const matchesSearch = 
            String(req.id || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
            req.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            req.pickupLocation?.toLowerCase().includes(searchTerm.toLowerCase());
        
        if (isAdmin) return matchesSearch;
        
        // Client view: only show their own requests
        const clientMatches = (req.clientId === currentUser?.clientId) ||
                             (req.clientName === currentUser?.name && !currentUser?.clientId);
        return matchesSearch && clientMatches;
    });

    const toggleAmenity = (item) => {
        setAmenities(prev =>
            prev.includes(item) ? prev.filter(a => a !== item) : [...prev, item]
        );
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = new FormData(e.target);

        const request = {
            clientId: currentUser?.clientId || 'CLT-GUEST',
            clientName: currentUser?.name || 'Guest Client',
            serviceType,
            requestDate: editingRequest ? editingRequest.requestDate : new Date().toISOString().split('T')[0],
            dueDate: formData.get('dueDate'),
            pickupTime: formData.get('pickupTime'),
            pickupLocation: formData.get('pickupLocation'),
            dropLocation: formData.get('dropLocation'),
            returnDate: serviceType === 'Round Trip' ? formData.get('returnDate') : null,
            returnTime: serviceType === 'Round Trip' ? formData.get('returnTime') : null,
            numberOfDays: serviceType === 'Daily Service' ? formData.get('numberOfDays') : null,
            numberOfPassengers: formData.get('numberOfPassengers') || 1,
            luggage: hasLuggage ? 'Yes' : 'No',
            bags: hasLuggage ? formData.get('bags') : 0,
            stops: hasStops ? 'Yes' : 'No',
            stopLocations: hasStops ? formData.get('stopLocations') : null,
            amenities: amenities,
            status: editingRequest?.status || 'Pending'
        };

        if (editingRequest) {
            updateChauffeurRequest({ ...editingRequest, ...request });
        } else {
            addChauffeurRequest(request);
        }

        setShowModal(false);
        resetForm();
    };

    const resetForm = () => {
        setEditingRequest(null);
        setServiceType('One Way');
        setHasLuggage(false);
        setHasStops(false);
        setAmenities([]);
        setModalType('create');
    };

    const openModal = (type, req = null) => {
        setModalType(type);
        if (req) {
            setEditingRequest(req);
            setServiceType(req.serviceType);
            setHasLuggage(req.luggage === 'Yes');
            setHasStops(req.stops === 'Yes');
            setAmenities(req.amenities || []);
        } else {
            resetForm();
        }
        setShowModal(true);
    };

    const handleCancel = async (id) => {
        if ((await swalConfirm('Cancel Booking', 'Are you sure?')).isConfirmed) {
            const request = chauffeurRequests.find(r => r.id === id);
            updateChauffeurRequest({ ...request, status: 'Cancelled' });
        }
    };

    const columns = [
        { header: "ID", accessor: "id" },
        { header: "Client", accessor: "clientName" },
        { header: "Type", accessor: "serviceType" },
        { header: "Date", accessor: "dueDate" },
        { header: "Time", accessor: "pickupTime" },
        { header: "Pickup", accessor: "pickupLocation" },
        { 
            header: "Status", 
            accessor: "status",
            render: (row) => <StatusBadge status={row.status} />
        }
    ];

    return (
        <div className="space-y-8 pb-20">
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-black tracking-tighter text-white italic uppercase">Chauffeur Protocol</h1>
                    <p className="text-secondary text-xs mt-1 font-black uppercase tracking-[0.2em] opacity-70 italic">
                        {isAdmin ? 'Elite Fleet Management & Logistic Control' : 'Elite transport & chauffeur protocol'}
                    </p>
                </div>
                {!isAdmin && (
                    <button
                        onClick={() => openModal('create')}
                        className="btn-primary group flex items-center gap-3 px-8 shadow-xl shadow-accent/20"
                    >
                        <Car size={18} className="group-hover:translate-x-1 transition-transform duration-300" />
                        <span>Book Chauffeur</span>
                    </button>
                )}
            </div>

            {/* Stats/Info Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-card p-6 border-l-4 border-l-accent flex items-center gap-6">
                    <div className="w-12 h-12 rounded-xl bg-accent/20 flex items-center justify-center text-accent shrink-0 shadow-2xl">
                        <Info size={24} />
                    </div>
                    <div>
                        <h3 className="text-sm font-black text-white italic uppercase tracking-tight">Protocol Status</h3>
                        <p className="text-secondary text-xs font-medium opacity-80 uppercase tracking-widest mt-1">
                            {isAdmin ? 'System Active' : 'Elite Access Granted'}
                        </p>
                    </div>
                </div>
                {isAdmin && (
                    <>
                        <div className="glass-card p-6 border-l-4 border-l-info flex items-center gap-6">
                            <div className="w-12 h-12 rounded-xl bg-info/20 flex items-center justify-center text-info shrink-0 shadow-2xl">
                                <Car size={24} />
                            </div>
                            <div>
                                <h3 className="text-sm font-black text-white italic uppercase tracking-tight">Active Fleet</h3>
                                <p className="text-secondary text-xs font-medium opacity-80 uppercase tracking-widest mt-1">
                                    {chauffeurRequests.filter(r => r.status === 'In Transit').length} Operations
                                </p>
                            </div>
                        </div>
                        <div className="glass-card p-6 border-l-4 border-l-warning flex items-center gap-6">
                            <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center text-warning shrink-0 shadow-2xl">
                                <Clock size={24} />
                            </div>
                            <div>
                                <h3 className="text-sm font-black text-white italic uppercase tracking-tight">Pending Dispatch</h3>
                                <p className="text-secondary text-xs font-medium opacity-80 uppercase tracking-widest mt-1">
                                    {chauffeurRequests.filter(r => r.status === 'Pending').length} Manifests
                                </p>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* List/Table Section */}
            <div className="glass-card p-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                    <h2 className="text-[10px] font-black text-muted uppercase tracking-[0.3em]">
                        {isAdmin ? 'Fleet Manifest Intelligence' : 'Booking History'}
                    </h2>
                    <div className="relative w-full md:w-64">
                        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
                        <input 
                            type="text" 
                            placeholder="Search manifest ID..." 
                            className="w-full bg-background border border-border rounded-xl py-2 pl-12 pr-4 text-xs focus:outline-none focus:border-accent"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                {isAdmin ? (
                    <Table 
                        columns={columns}
                        data={filteredRequests}
                        actions={true}
                        onView={(row) => openModal('view', row)}
                        onEdit={(row) => openModal('edit', row)}
                        onDelete={(row) => deleteChauffeurRequest(row.id)}
                    />
                ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {filteredRequests.length === 0 ? (
                            <div className="col-span-2 glass-card p-12 text-center border-dashed border-2 border-white/5">
                                <Car size={48} className="text-muted mx-auto mb-4 opacity-20" />
                                <p className="text-secondary font-bold uppercase tracking-widest text-xs italic">No active bookings detected</p>
                            </div>
                        ) : (
                            filteredRequests.map((req, i) => (
                                <motion.div
                                    key={req.id}
                                    initial={{ opacity: 0, x: -20 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: i * 0.1 }}
                                    className="glass-card p-6 border-border hover:border-accent/30 transition-all group relative overflow-hidden"
                                >
                                    <div className="absolute top-0 right-0 p-4">
                                        <StatusBadge status={req.status} />
                                    </div>

                                    <div className="flex items-center gap-4 mb-4">
                                        <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-accent">
                                            <Navigation size={20} />
                                        </div>
                                        <div>
                                            <p className="text-[10px] font-black text-muted uppercase tracking-widest">{req.id}</p>
                                            <p className="text-sm font-black text-white italic uppercase tracking-tight">{req.serviceType}</p>
                                        </div>
                                    </div>

                                    <div className="space-y-3">
                                        <div className="flex items-center gap-3">
                                            <MapPin size={14} className="text-accent shrink-0" />
                                            <div className="min-w-0">
                                                <p className="text-[8px] font-black text-muted uppercase">Pickup Location</p>
                                                <p className="text-xs font-bold text-secondary truncate">{req.pickupLocation}</p>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-3">
                                            <Clock size={14} className="text-muted shrink-0" />
                                            <div>
                                                <p className="text-[8px] font-black text-muted uppercase">Pickup Time</p>
                                                <p className="text-xs font-bold text-secondary">{req.dueDate || req.pickupDate} @ {req.pickupTime}</p>
                                            </div>
                                        </div>

                                        <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/5">
                                            <button onClick={() => openModal('edit', req)} disabled={req.status === 'Cancelled' || req.status === 'Completed'} className={`flex-1 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${req.status === 'Cancelled' || req.status === 'Completed' ? 'bg-white/5 text-muted cursor-not-allowed' : 'bg-white/10 text-white hover:bg-white/20'}`}>
                                                Edit/Reschedule
                                            </button>
                                            <button onClick={() => handleCancel(req.id)} disabled={req.status === 'Cancelled' || req.status === 'Completed'} className={`py-2 px-4 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${req.status === 'Cancelled' || req.status === 'Completed' ? 'bg-white/5 text-muted cursor-not-allowed' : 'bg-danger/20 text-danger hover:bg-danger/30'}`}>
                                                Cancel
                                            </button>
                                        </div>
                                    </div>
                                </motion.div>
                            ))
                        )}
                    </div>
                )}
            </div>

            {/* Modal */}
            <AnimatePresence>
                {showModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="absolute inset-0 bg-black/90 backdrop-blur-md"
                            onClick={() => setShowModal(false)}
                        />
                        <motion.div
                            initial={{ scale: 0.9, opacity: 0, y: 30 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.9, opacity: 0, y: 30 }}
                            className="w-full max-w-2xl bg-sidebar border border-border rounded-[3rem] shadow-2xl relative z-10 overflow-hidden"
                        >
                            <div className="p-8 pb-4 border-b border-white/5 flex items-center justify-between">
                                <div>
                                    <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter">
                                        {modalType === 'view' ? 'Manifest Details' : editingRequest ? 'Modify Transport Protocol' : 'Initialize Transport Protocol'}
                                    </h3>
                                    <p className="text-xs text-secondary italic mt-1 font-black tracking-widest uppercase opacity-70">
                                        {modalType === 'view' ? 'Institutional Verification' : 'Define transport manifest'}
                                    </p>
                                </div>
                                <button type="button" onClick={() => setShowModal(false)} className="p-3 bg-white/5 border border-border rounded-full text-muted hover:text-white transition-all">
                                    <X size={20} />
                                </button>
                            </div>

                            <form onSubmit={handleSubmit} className="p-8 space-y-6 max-h-[70vh] overflow-y-auto custom-scrollbar">
                                {modalType === 'view' ? (
                                    <div className="space-y-6">
                                        <div className="p-6 bg-accent/5 rounded-2xl border border-accent/20 flex items-center justify-between">
                                            <div className="flex items-center gap-4">
                                                <div className="w-12 h-12 bg-accent/20 rounded-xl flex items-center justify-center text-accent">
                                                    <Car size={24} />
                                                </div>
                                                <div>
                                                    <h4 className="font-bold text-lg text-white">{editingRequest?.id}</h4>
                                                    <p className="text-xs text-secondary uppercase font-black tracking-widest">{editingRequest?.serviceType}</p>
                                                </div>
                                            </div>
                                            <StatusBadge status={editingRequest?.status} />
                                        </div>

                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="p-4 bg-white/5 rounded-xl border border-border">
                                                <p className="text-[10px] text-muted uppercase font-black tracking-widest mb-1">Entity / Client</p>
                                                <p className="text-sm font-bold text-white">{editingRequest?.clientName}</p>
                                            </div>
                                            <div className="p-4 bg-white/5 rounded-xl border border-border">
                                                <p className="text-[10px] text-muted uppercase font-black tracking-widest mb-1">Execution Date</p>
                                                <p className="text-sm font-bold text-white">{editingRequest?.dueDate} @ {editingRequest?.pickupTime}</p>
                                            </div>
                                            <div className="p-4 bg-white/5 rounded-xl border border-border col-span-2">
                                                <p className="text-[10px] text-muted uppercase font-black tracking-widest mb-1">Pickup Vector</p>
                                                <p className="text-sm font-bold text-white italic">{editingRequest?.pickupLocation}</p>
                                            </div>
                                            <div className="p-4 bg-white/5 rounded-xl border border-border col-span-2">
                                                <p className="text-[10px] text-muted uppercase font-black tracking-widest mb-1">Destination Vector</p>
                                                <p className="text-sm font-bold text-white italic">{editingRequest?.dropLocation}</p>
                                            </div>
                                        </div>

                                        {isAdmin && (
                                            <div className="space-y-4 pt-4 border-t border-white/5">
                                                <label className="text-[10px] font-black text-accent uppercase tracking-widest">Protocol Intervention (Admin)</label>
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div className="space-y-1">
                                                        <label className="text-[8px] font-black text-muted uppercase">Assign Operative</label>
                                                        <select 
                                                            className="w-full bg-background border border-border rounded-lg px-4 py-2 text-xs text-white"
                                                            value={editingRequest?.driverId}
                                                            onChange={(e) => updateChauffeurRequest({...editingRequest, driverId: e.target.value, driverName: users.find(u => u.id === e.target.value)?.name})}
                                                        >
                                                            <option>Select Operative...</option>
                                                            {users.filter(u => u.role === 'Staff').map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                                                        </select>
                                                    </div>
                                                    <div className="space-y-1">
                                                        <label className="text-[8px] font-black text-muted uppercase">Update Status</label>
                                                        <select 
                                                            className="w-full bg-background border border-border rounded-lg px-4 py-2 text-xs text-white"
                                                            value={editingRequest?.status}
                                                            onChange={(e) => updateChauffeurRequest({...editingRequest, status: e.target.value})}
                                                        >
                                                            <option>Pending</option>
                                                            <option>Confirmed</option>
                                                            <option>In Transit</option>
                                                            <option>Completed</option>
                                                            <option>Cancelled</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <>
                                        {/* Service Type Selection */}
                                        <div className="space-y-4">
                                            <label className="text-[10px] font-black text-muted uppercase tracking-[0.2em] pl-1">Select Service Protocol</label>
                                            <div className="grid grid-cols-3 gap-3">
                                                {['One Way', 'Round Trip', 'Daily Service'].map(type => (
                                                    <button
                                                        key={type}
                                                        type="button"
                                                        onClick={() => setServiceType(type)}
                                                        className={`py-4 px-2 rounded-2xl border-2 transition-all text-xs font-black uppercase tracking-tight flex flex-col items-center gap-2 ${serviceType === type
                                                            ? 'bg-accent/10 border-accent text-accent shadow-lg shadow-accent/5'
                                                            : 'bg-white/[0.02] border-border text-muted hover:border-white/20'
                                                            }`}
                                                    >
                                                        <div className={`p-2 rounded-lg ${serviceType === type ? 'bg-accent/20' : 'bg-white/5'}`}>
                                                            {type === 'One Way' ? <ArrowRight size={16} /> : type === 'Round Trip' ? <Navigation size={16} /> : <Calendar size={16} />}
                                                        </div>
                                                        {type}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>

                                        <div className="grid grid-cols-2 gap-6 pt-4">
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-muted uppercase tracking-widest pl-1">Request Date</label>
                                                <input type="text" value={editingRequest ? editingRequest.requestDate : new Date().toISOString().split('T')[0]} disabled className="w-full bg-background/50 border border-border rounded-2xl px-5 py-4 text-sm text-muted focus:outline-none font-bold" />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-muted uppercase tracking-widest pl-1">Due Date (Pickup)</label>
                                                <input type="date" name="dueDate" defaultValue={editingRequest?.dueDate} required className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-muted uppercase tracking-widest pl-1">Pickup Time</label>
                                                <input type="time" name="pickupTime" defaultValue={editingRequest?.pickupTime} required className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                            </div>
                                            <div className="space-y-2">
                                                <label className="text-[10px] font-black text-muted uppercase tracking-widest pl-1">Passengers</label>
                                                <input type="number" name="numberOfPassengers" min="1" max="10" defaultValue={editingRequest?.numberOfPassengers || 1} required placeholder="1" className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black text-muted uppercase tracking-[0.2em] pl-1 text-accent">Pickup Location</label>
                                            <div className="relative">
                                                <MapPin className="absolute left-5 top-1/2 -translate-y-1/2 text-accent" size={18} />
                                                <input
                                                    type="text"
                                                    name="pickupLocation"
                                                    defaultValue={editingRequest?.pickupLocation}
                                                    required
                                                    placeholder="Street, Hotel Name, or Airport Terminal..."
                                                    className="w-full bg-background border border-border rounded-2xl py-4 pl-14 pr-5 text-sm text-white focus:outline-none focus:border-accent font-bold"
                                                />
                                            </div>
                                        </div>

                                        <div className="space-y-2">
                                            <label className="text-[10px] font-black text-muted uppercase tracking-[0.2em] pl-1">Drop Location</label>
                                            <div className="relative">
                                                <Navigation className="absolute left-5 top-1/2 -translate-y-1/2 text-muted" size={18} />
                                                <input
                                                    type="text"
                                                    name="dropLocation"
                                                    defaultValue={editingRequest?.dropLocation}
                                                    required
                                                    placeholder="Destination address..."
                                                    className="w-full bg-background border border-border rounded-2xl py-4 pl-14 pr-5 text-sm text-white focus:outline-none focus:border-accent font-bold"
                                                />
                                            </div>
                                        </div>

                                        {serviceType === 'Round Trip' && (
                                            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 bg-accent/5 p-6 rounded-3xl border border-accent/20">
                                                <div className="grid grid-cols-2 gap-6">
                                                    <div className="space-y-2">
                                                        <label className="text-[10px] font-black text-accent uppercase tracking-widest pl-1 italic">Return Date</label>
                                                        <input type="date" name="returnDate" defaultValue={editingRequest?.returnDate} required className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                                    </div>
                                                    <div className="space-y-2">
                                                        <label className="text-[10px] font-black text-accent uppercase tracking-widest pl-1 italic">Return Time</label>
                                                        <input type="time" name="returnTime" defaultValue={editingRequest?.returnTime} required className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                                    </div>
                                                </div>
                                            </motion.div>
                                        )}

                                        {serviceType === 'Daily Service' && (
                                            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-2 bg-accent/5 p-4 rounded-3xl border border-accent/20">
                                                <label className="text-[10px] font-black text-accent uppercase tracking-widest pl-1 italic">Requested Duration (Days)</label>
                                                <input type="number" name="numberOfDays" min="1" defaultValue={editingRequest?.numberOfDays} required placeholder="e.g. 5" className="w-full bg-background border border-border rounded-2xl px-5 py-4 text-sm text-white focus:outline-none focus:border-accent font-bold" />
                                            </motion.div>
                                        )}

                                        <div className="grid grid-cols-2 gap-4">
                                            <button
                                                type="button"
                                                onClick={() => setHasLuggage(!hasLuggage)}
                                                className={`p-4 rounded-2xl border flex items-center justify-between transition-all ${hasLuggage ? 'bg-accent/10 border-accent/40' : 'bg-white/5 border-border'}`}
                                            >
                                                <div className="flex items-center gap-2">
                                                    <Luggage size={16} className={hasLuggage ? 'text-accent' : 'text-muted'} />
                                                    <span className={`text-[10px] font-black uppercase tracking-tight ${hasLuggage ? 'text-white' : 'text-muted'}`}>Luggage</span>
                                                </div>
                                            </button>

                                            <button
                                                type="button"
                                                onClick={() => setHasStops(!hasStops)}
                                                className={`p-4 rounded-2xl border flex items-center justify-between transition-all ${hasStops ? 'bg-accent/10 border-accent/40' : 'bg-white/5 border-border'}`}
                                            >
                                                <div className="flex items-center gap-2">
                                                    <Clock4 size={16} className={hasStops ? 'text-accent' : 'text-muted'} />
                                                    <span className={`text-[10px] font-black uppercase tracking-tight ${hasStops ? 'text-white' : 'text-muted'}`}>Extra Stops</span>
                                                </div>
                                            </button>
                                        </div>

                                        <div className="space-y-4">
                                            <label className="text-[10px] font-black text-muted uppercase tracking-[0.2em] pl-1">Extra Amenities Protocol</label>
                                            <div className="flex flex-wrap gap-2">
                                                {['Baby Car Seat', 'WiFi', 'Refreshments'].map(item => (
                                                    <button
                                                        key={item}
                                                        type="button"
                                                        onClick={() => toggleAmenity(item)}
                                                        className={`px-4 py-3 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all ${amenities.includes(item) ? 'bg-accent/20 border-accent text-accent' : 'bg-white/[0.02] border-white/5 text-muted'}`}
                                                    >
                                                        {item}
                                                    </button>
                                                ))}
                                            </div>
                                        </div>
                                    </>
                                )}

                                <div className="pt-10 flex items-center justify-end gap-4 pb-4">
                                    <button type="button" onClick={() => setShowModal(false)} className="text-muted text-[10px] font-black uppercase tracking-widest hover:text-white transition-all px-4">Abort</button>
                                    {modalType !== 'view' && (
                                        <button type="submit" className="btn-primary flex items-center gap-3 px-12 py-5 shadow-2xl shadow-accent/20">
                                            <CheckCircle size={20} />
                                            <span>{editingRequest ? 'Update Protocol' : 'Confirm Protocol'}</span>
                                        </button>
                                    )}
                                </div>
                            </form>
                        </motion.div>
                    </div>
                )}
            </AnimatePresence>
        </div>
    );
};

export default Chauffeur;
